#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 18:20:21 2022

Enterprise_extensions models, but slightly modifed.

adjustments:
    white noise prior ranges can be adjusted
    power law prior ranges can be adjusted
    time-domain GP amplitude prior range can be adjusted
    number of PL components may be specified independently for RN, DM,
        and chromatic noise
    Option to vary chromatic index on DM exponential dip
    DM dip priors on tau and idx can be adjusted
    Turnover kappa and fb priors can be adjusted
    Adding custom broken power law model into the red noise block
    Custom solar wind block that takes a flag which applies the signal to
        only NG data if True
    Option to apply selections for DR3, as opposed to defaults using NANOGrav
"""
   
# -*- coding: utf-8 -*-

from collections import OrderedDict

import numpy as np
from enterprise import constants as const
from enterprise.signals import (deterministic_signals, gp_signals, parameter,
                                selections, signal_base, white_signals, utils)

from enterprise_extensions import chromatic as chrom
from enterprise_extensions.blocks import (common_red_noise_block,
                                          red_noise_block)
import enterprise_extensions.chromatic.solar_wind as sw
from enterprise_extensions.timing import timing_block
from enterprise_extensions import gp_kernels as gpk
from enterprise.signals import gp_priors as gpp
from enterprise.signals import gp_bases as gpb

from dr3_noise.selections import CustomSelections


# from enterprise.signals.signal_base import LookupLikelihood

yr_in_sec = 365.25*24*3600


def model_singlepsr_noise(psr, tm_var=False, tm_linear=False,
                          tmparam_list=None,
                          red_var=True, psd='powerlaw', red_select=None,
                          noisedict=None, tm_svd=False, tm_norm=True,
                          white_vary=True, inc_ecorr=True, gp_ecorr=False,
                          efac_min=0.01, efac_max=10, efac1=False,
                          log_equad_min=-8.5, log_equad_max=-5,
                          log_A_min=-20, log_A_max=-11,
                          log_fb_min=-9, log_fb_max=-7,
                          kappa_min=0, kappa_max=7,
                          log_sigma_min=-10, log_sigma_max=-4,
                          components=30, upper_limit=False,
                          is_wideband=False, use_dmdata=False, tnequad=False,
                          dmjump_var=False, gamma_val=None, dm_var=False,
                          dm_type='gp', dmgp_kernel='diag', dm_psd='powerlaw',
                          dm_nondiag_kernel='periodic', dmx_data=None,
                          dm_annual=False, gamma_dm_val=None,
                          dm_dt=15, dm_df=200, dm_Nfreqs=100,
                          chrom_gp=False, chrom_gp_kernel='nondiag',
                          chrom_psd='powerlaw', chrom_idx=4, chrom_quad=False,
                          chrom_log_A_min=None, chrom_log_A_max=None,
                          chrom_gamma_min=0, chrom_gamma_max=7,
                          chrom_kernel='periodic',
                          chrom_dt=15, chrom_df=200, chrom_components=150,
                          dmjump=False, dmjump_flags=[], dmjump_group_names=[],
                          dm_expdip=False, dmexp_sign='negative',
                          dm_expdip_idx=2, dm_expdip_basename='dmexp',
                          dm_expdip_idx_min=0, dm_expdip_idx_max=6,
                          dm_expdip_tau_min=0, dm_expdip_tau_max=2.5,
                          dm_expdip_A_min=-10, dm_expdip_A_max=-2,
                          dm_expdip_tmin=None, dm_expdip_tmax=None,
                          num_dmdips=1, dmdip_seqname=None,
                          dm_cusp=False, dm_cusp_sign='negative',
                          dm_cusp_idx=2, dm_cusp_sym=False,
                          dm_cusp_tmin=None, dm_cusp_tmax=None,
                          num_dm_cusps=1, dm_cusp_seqname=None,
                          dm_dual_cusp=False, dm_dual_cusp_tmin=None,
                          dm_dual_cusp_tmax=None, dm_dual_cusp_sym=False,
                          dm_dual_cusp_idx1=2, dm_dual_cusp_idx2=4,
                          dm_dual_cusp_sign='negative', num_dm_dual_cusps=1,
                          dm_dual_cusp_seqname=None,
                          dm_sw_deter=False, dm_sw_gp=False, ACE_prior=True,
                          swgp_prior=None, swgp_basis=None, sw_select=None,
                          sw_vals_path=None, sw_bins=None, sw_r4p4=False,
                          coefficients=False, extra_sigs=None,
                          psr_model=False, factorized_like=False,
                          Tspan=None, fact_like_gamma=13./3, gw_components=10,
                          fact_like_logmin=None, fact_like_logmax=None,
                          select='backend', tm_marg=False, dense_like=False,
                          ng_twg_setup=False, wb_efac_sigma=0.25,
                          tm_basis_combine=True, wideband=None,
                          efeq_groups=None, ecorr_groups=None):
    """
    Single pulsar noise model. Modifed from version in enterprise_extensions
    with following changes:
        'dm_Nfreqs' a separate parameter from 'components'
        Setup white noise params for DR3 data using a dictionaries as input
        
    :param psr: enterprise pulsar object
    :param tm_var: explicitly vary the timing model parameters
    :param tm_linear: vary the timing model in the linear approximation
    :param tmparam_list: an explicit list of timing model parameters to vary
    :param red_var: include red noise in the model
    :param psd: red noise psd model
    :param noisedict: dictionary of noise parameters
    :param tm_svd: boolean for svd-stabilised timing model design matrix
    :param tm_norm: normalize the timing model, or provide custom normalization
    :param white_vary: boolean for varying white noise or keeping fixed
    :param components: number of modes in Fourier domain processes
    :param dm_components: number of modes in Fourier domain DM processes
    :param upper_limit: whether to do an upper-limit analysis
    :param is_wideband: whether input TOAs are wideband TOAs; will exclude
           ecorr from the white noise model
    :param use_dmdata: whether to use DM data (WidebandTimingModel) if
           is_wideband
    :param gamma_val: red noise spectral index to fix
    :param dm_var: whether to explicitly model DM-variations
    :param dm_type: gaussian process ('gp') or dmx ('dmx')
    :param dmgp_kernel: diagonal in frequency or non-diagonal
    :param dm_psd: power-spectral density of DM variations
    :param dm_nondiag_kernel: type of time-domain DM GP kernel
    :param dmx_data: supply the DMX data from par files
    :param dm_annual: include an annual DM signal
    :param gamma_dm_val: spectral index of power-law DM variations
    :param dm_dt: time-scale for DM linear interpolation basis (days)
    :param dm_df: frequency-scale for DM linear interpolation basis (MHz)
    :param chrom_gp: include general chromatic noise
    :param chrom_gp_kernel: GP kernel type to use in chrom ['diag','nondiag']
    :param chrom_psd: power-spectral density of chromatic noise
        ['powerlaw','tprocess','free_spectrum']
    :param chrom_idx: frequency scaling of chromatic noise
    :param chrom_kernel: Type of 'nondiag' time-domain chrom GP kernel to use
        ['periodic', 'sq_exp','periodic_rfband', 'sq_exp_rfband']
    :param chrom_quad: Whether to add a quadratic chromatic term. Boolean
    :param chrom_dt: time-scale for chromatic linear interpolation basis (days)
    :param chrom_df: frequency-scale for chromatic linear interpolation basis
        (MHz)
    :param dm_expdip: inclue a DM exponential dip
    :param dmexp_sign: set the sign parameter for dip
    :param dm_expdip_idx: chromatic index of exponential dip
    :param dm_expdip_tmin: sampling minimum of DM dip epoch
    :param dm_expdip_tmax: sampling maximum of DM dip epoch
    :param num_dmdips: number of dm exponential dips
    :param dmdip_seqname: name of dip sequence
    :param dm_cusp: include a DM exponential cusp
    :param dm_cusp_sign: set the sign parameter for cusp
    :param dm_cusp_idx: chromatic index of exponential cusp
    :param dm_cusp_tmin: sampling minimum of DM cusp epoch
    :param dm_cusp_tmax: sampling maximum of DM cusp epoch
    :param dm_cusp_sym: make exponential cusp symmetric
    :param num_dm_cusps: number of dm exponential cusps
    :param dm_cusp_seqname: name of cusp sequence
    :param dm_dual_cusp: include a DM cusp with two chromatic indices
    :param dm_dual_cusp_tmin: sampling minimum of DM dual cusp epoch
    :param dm_dual_cusp_tmax: sampling maximum of DM dual cusp epoch
    :param dm_dual_cusp_idx1: first chromatic index of DM dual cusp
    :param dm_dual_cusp_idx2: second chromatic index of DM dual cusp
    :param dm_dual_cusp_sym: make dual cusp symmetric
    :param dm_dual_cusp_sign: set the sign parameter for dual cusp
    :param num_dm_dual_cusps: number of DM dual cusps
    :param dm_dual_cusp_seqname: name of dual cusp sequence
    :param dm_scattering: whether to explicitly model DM scattering variations
    :param dm_sw_deter: use the deterministic solar wind model
    :param dm_sw_gp: add a Gaussian process perturbation to the deterministic
        solar wind model.
    :param swgp_prior: prior is currently set automatically
    :param swgp_basis: ['powerlaw', 'periodic', 'sq_exp']
    :param sw_selection: [None, 'NG_only', 'by_PTA']
    :param coefficients: explicitly include latent coefficients in model
    :param psr_model: Return the enterprise model instantiated on the pulsar
        rather than an instantiated PTA object, i.e. model(psr) rather than
        PTA(model(psr)).
    :param factorized_like: Whether to run a factorized likelihood analyis
        Boolean
    :param gw_components: number of modes in Fourier domain for a common
           process in a factorized likelihood calculation.
    :param fact_like_gamma: fixed common process spectral index
    :param fact_like_logmin: specify lower prior for common psd. This is a
        prior on log10_rho if common_psd is 'spectrum', else it is a prior on
        log10 amplitude
    :param fact_like_logmax: specify upper prior for common psd. This is a
        prior on log10_rho if common_psd is 'spectrum', else it is a prior on
        log10 amplitude
    :param Tspan: time baseline used to determine Fourier GP frequencies
    :param extra_sigs: Any additional `enterprise` signals to be added to the
        model.
    :param tm_marg: Use marginalized timing model. In many cases this will
        speed up the likelihood calculation significantly.
    :param dense_like: Use dense or sparse functions to evalute lnlikelihood
    :return s: single pulsar noise model
    """
    amp_prior = 'uniform' if upper_limit else 'log-uniform'

    # timing model
    if not tm_var:
        if (is_wideband and use_dmdata):
            if dmjump_var:
                dmjump = parameter.Uniform(pmin=-0.005, pmax=0.005)
            else:
                dmjump = parameter.Constant()
            if white_vary:
                dmefac = parameter.Uniform(pmin=0.1, pmax=10)
                log10_dmequad = parameter.Uniform(pmin=-7.0, pmax=0.0)
                # dmjump = parameter.Uniform(pmin=-0.005, pmax=0.005)
            else:
                dmefac = parameter.Constant()
                log10_dmequad = parameter.Constant()
                # dmjump = parameter.Constant()
            s = gp_signals.WidebandTimingModel(dmefac=dmefac,
                                               log10_dmequad=log10_dmequad,
                                               dmjump=dmjump,
                                               dmefac_selection=
                                               selections.Selection(
                                                   selections.by_backend),
                                               log10_dmequad_selection=
                                               selections.Selection(
                                                   selections.by_backend),
                                               dmjump_selection=
                                               selections.Selection(
                                                   selections.by_frontend))
        else:
            if tm_marg:
                s = gp_signals.MarginalizingTimingModel(use_svd=tm_svd)
            else:
                s = gp_signals.TimingModel(use_svd=tm_svd, normed=tm_norm,
                                           coefficients=coefficients)
    else:
        # create new attribute for enterprise pulsar object
        psr.tmparams_orig = OrderedDict.fromkeys(psr.t2pulsar.pars())
        for key in psr.tmparams_orig:
            psr.tmparams_orig[key] = (psr.t2pulsar[key].val,
                                      psr.t2pulsar[key].err)
        if not tm_linear:
            s = timing_block(tmparam_list=tmparam_list)
        else:
            pass

    # red noise and common process
    if factorized_like:
        if Tspan is None:
            msg = 'Must Timespan to match amongst all pulsars when doing '
            msg += 'a factorized likelihood analysis.'
            raise ValueError(msg)

        s += common_red_noise_block(psd=psd, prior=amp_prior,
                                    Tspan=Tspan, components=gw_components,
                                    gamma_val=fact_like_gamma, delta_val=None,
                                    orf=None, name='gw',
                                    coefficients=coefficients,
                                    pshift=False, pseed=None,
                                    logmin=fact_like_logmin,
                                    logmax=fact_like_logmax)

    if red_var:
        s += red_noise_block(psd=psd, prior=amp_prior, Tspan=Tspan,
                             components=components, gamma_val=gamma_val,
                             coefficients=coefficients, select=red_select,
                             logmin=log_A_min, logmax=log_A_max)
    # DM variations
    if dm_var:
        if dm_type == 'gp':
            if dmgp_kernel == 'diag':
                # Block for Fourier basis DM noise
                s += dm_noise_block(gp_kernel=dmgp_kernel, psd=dm_psd,
                                    prior=amp_prior, components=dm_Nfreqs,
                                    logmin=log_A_min, logmax=log_A_max,
                                    logmin_fb=log_fb_min, logmax_fb=log_fb_max,
                                    min_kappa=kappa_min, max_kappa=kappa_max,
                                    gamma_val=gamma_dm_val, Tspan=Tspan,
                                    coefficients=coefficients)
            elif dmgp_kernel == 'nondiag':
                s += dm_noise_block(gp_kernel=dmgp_kernel,
                                    nondiag_kernel=dm_nondiag_kernel,
                                    logmin_sigma=log_sigma_min,
                                    logmax_sigma=log_sigma_max,
                                    dt=dm_dt, df=dm_df,
                                    coefficients=coefficients)
        elif dm_type == 'dmx':
            s += chrom.dmx_signal(dmx_data=dmx_data[psr.name])
        if dm_annual:
            s += chrom.dm_annual_signal()
        if chrom_gp:
            if chrom_log_A_min == None:
                chrom_log_A_min = log_A_min
            if chrom_log_A_max == None:
                chrom_log_A_max = log_A_max
            s += chromatic_noise_block(gp_kernel=chrom_gp_kernel,
                                       psd=chrom_psd, idx=chrom_idx,
                                       components=chrom_components,
                                       logmin=chrom_log_A_min,
                                       logmax=chrom_log_A_max,
                                       gmin=chrom_gamma_min,
                                       gmax=chrom_gamma_max,
                                       logmin_sigma=log_sigma_min,
                                       logmax_sigma=log_sigma_max,
                                       nondiag_kernel=chrom_kernel,
                                       dt=chrom_dt, df=chrom_df,
                                       include_quadratic=chrom_quad,
                                       coefficients=coefficients,
                                       Tspan=Tspan)

        if dm_expdip:
            if dm_expdip_tmin is None and dm_expdip_tmax is None:
                tmin = [psr.toas.min() / const.day for ii in range(num_dmdips)]
                tmax = [psr.toas.max() / const.day for ii in range(num_dmdips)]
            else:
                tmin = (dm_expdip_tmin if isinstance(dm_expdip_tmin, list)
                        else [dm_expdip_tmin])
                tmax = (dm_expdip_tmax if isinstance(dm_expdip_tmax, list)
                        else [dm_expdip_tmax])
            expdip_idx = (dm_expdip_idx if isinstance(dm_expdip_idx, list)
                          else [dm_expdip_idx]*num_dmdips)
            idx_min = (dm_expdip_idx_min if isinstance(dm_expdip_idx_min, list)
                       else [dm_expdip_idx_min]*num_dmdips)
            idx_max = (dm_expdip_idx_max if isinstance(dm_expdip_idx_max, list)
                       else [dm_expdip_idx_max]*num_dmdips)
            tau_min = (dm_expdip_tau_min if isinstance(dm_expdip_tau_min, list)
                       else [dm_expdip_tau_min]*num_dmdips)
            tau_max = (dm_expdip_tau_max if isinstance(dm_expdip_tau_max, list)
                       else [dm_expdip_tau_max]*num_dmdips)
            A_min = (dm_expdip_A_min if isinstance(dm_expdip_A_min, list)
                       else [dm_expdip_A_min]*num_dmdips)
            A_max = (dm_expdip_A_max if isinstance(dm_expdip_A_max, list)
                       else [dm_expdip_A_max]*num_dmdips)
            if dmdip_seqname is not None:
                dmdipname_base = ([f'{dm_expdip_basename}_' + nm for nm in
                                   dmdip_seqname]
                                  if isinstance(dmdip_seqname, list)
                                  else ['dmexp_' + dmdip_seqname])
            else:
                dmdipname_base = [f'{dm_expdip_basename}{ii+1}'
                                  for ii in range(num_dmdips)]

            for dd in range(num_dmdips):
                # using custom DM exponential dip
                s += dm_exponential_dip(tmin=tmin[dd], tmax=tmax[dd],
                                        idx=expdip_idx[dd],
                                        idx_min=idx_min[dd],
                                        idx_max=idx_max[dd],
                                        log10_tau_min=tau_min[dd],
                                        log10_tau_max=tau_max[dd],
                                        log10_A_min=A_min[dd],
                                        log10_A_max=A_max[dd],
                                        sign=dmexp_sign,
                                        name=dmdipname_base[dd])
        if dm_cusp:
            if dm_cusp_tmin is None and dm_cusp_tmax is None:
                tmin = [psr.toas.min() / const.day
                        for ii in range(num_dm_cusps)]
                tmax = [psr.toas.max() / const.day
                        for ii in range(num_dm_cusps)]
            else:
                tmin = (dm_cusp_tmin if isinstance(dm_cusp_tmin, list)
                        else [dm_cusp_tmin])
                tmax = (dm_cusp_tmax if isinstance(dm_cusp_tmax, list)
                        else [dm_cusp_tmax])
            if dm_cusp_seqname is not None:
                cusp_name_base = 'dm_cusp_'+dm_cusp_seqname+'_'
            else:
                cusp_name_base = 'dm_cusp_'
            dm_cusp_idx = (dm_cusp_idx if isinstance(dm_cusp_idx, list)
                           else [dm_cusp_idx])
            dm_cusp_sign = (dm_cusp_sign if isinstance(dm_cusp_sign, list)
                            else [dm_cusp_sign])
            for dd in range(1, num_dm_cusps+1):
                s += chrom.dm_exponential_cusp(tmin=tmin[dd-1],
                                               tmax=tmax[dd-1],
                                               idx=dm_cusp_idx[dd-1],
                                               sign=dm_cusp_sign[dd-1],
                                               symmetric=dm_cusp_sym,
                                               name=cusp_name_base+str(dd))
        if dm_dual_cusp:
            if dm_dual_cusp_tmin is None and dm_cusp_tmax is None:
                tmin = psr.toas.min() / const.day
                tmax = psr.toas.max() / const.day
            else:
                tmin = dm_dual_cusp_tmin
                tmax = dm_dual_cusp_tmax
            if dm_dual_cusp_seqname is not None:
                dual_cusp_name_base = 'dm_dual_cusp_'+dm_cusp_seqname+'_'
            else:
                dual_cusp_name_base = 'dm_dual_cusp_'
            for dd in range(1, num_dm_dual_cusps+1):
                s += chrom.dm_dual_exp_cusp(tmin=tmin, tmax=tmax,
                                            idx1=dm_dual_cusp_idx1,
                                            idx2=dm_dual_cusp_idx2,
                                            sign=dm_dual_cusp_sign,
                                            symmetric=dm_dual_cusp_sym,
                                            name=dual_cusp_name_base+str(dd))
        if dm_sw_deter:
            if not Tspan:
                Tspan = psr.toas.max() - psr.toas.min()
            s += solar_wind_block(ACE_prior=ACE_prior, include_swgp=dm_sw_gp,
                                  swgp_prior=swgp_prior, swgp_basis=swgp_basis,
                                  Tspan=Tspan, selection=sw_select)

    if extra_sigs is not None:
        s += extra_sigs

    # adding white-noise
    s += white_noise_block(vary=white_vary, inc_ecorr=inc_ecorr, 
                           gp_ecorr=gp_ecorr, tnequad=tnequad, select=select,
                           efac_min=efac_min, efac_max=efac_max, efac1=efac1,
                           log_equad_min=log_equad_min,
                           log_equad_max=log_equad_max,
                           efeq_groups=efeq_groups, ecorr_groups=ecorr_groups)
    
    # acting on psr objects
    model = s(psr)
    if psr_model:
        return s
    else:
        # set up PTA
        if dense_like:
            lnlike_Chol = signal_base.LogLikelihoodDenseCholesky
            pta = signal_base.PTA([model], lnlikelihood=lnlike_Chol)
        else:
            pta = signal_base.PTA([model])

        # set white noise parameters
        if not white_vary or (is_wideband and use_dmdata):
            if noisedict is None:
                print('No noise dictionary provided!...')
            else:
                noisedict = noisedict
                pta.set_default_params(noisedict)

        return pta


# CUSTOM noise block
def chromatic_noise_block(gp_kernel='nondiag', psd='powerlaw',
                          nondiag_kernel='periodic',
                          prior='log-uniform', dt=15, df=200,
                          logmin=-20, logmax=-11,
                          logmin_sigma=-10, logmax_sigma=-4,
                          idx=4, include_quadratic=False,
                          Tspan=None, name='chrom', components=30,
                          coefficients=False):
    """
    Modified from enterprise_extensions. This (by default) changes the min
    power law amplitude from 1e-18 to 1e-20
    
    Returns GP chromatic noise model :
        1. Chromatic modeled with user defined PSD with
        30 sampling frequencies. Available PSDs are
        ['powerlaw', 'turnover' 'spectrum']
    :param gp_kernel:
        Whether to use a diagonal kernel for the GP. ['diag','nondiag']
    :param nondiag_kernel:
        Which nondiagonal kernel to use for the GP.
        ['periodic','sq_exp','periodic_rfband','sq_exp_rfband']
    :param psd:
        PSD to use for common red noise signal. Available options
        are ['powerlaw', 'turnover' 'spectrum']
    :param prior:
        What type of prior to use for amplitudes. ['log-uniform','uniform']
    :param dt:
        time-scale for linear interpolation basis (days)
    :param df:
        frequency-scale for linear interpolation basis (MHz)
    :param idx:
        Index of radio frequency dependence (i.e. DM is 2). Any float will work
    :param include_quadratic:
        Whether to include a quadratic fit.
    :param name: Name of signal
    :param Tspan:
        Tspan from which to calculate frequencies for PSD-based GPs.
    :param components:
        Number of frequencies to use in 'diag' GPs.
    :param coefficients:
        Whether to keep coefficients of the GP.
    """
    if gp_kernel == 'diag':
        chm_basis = gpb.createfourierdesignmatrix_chromatic(nmodes=components,
                                                            Tspan=Tspan)
        if psd in ['powerlaw', 'turnover']:
            if prior == 'uniform':
                log10_A = parameter.LinearExp(logmin, logmax)
            elif prior == 'log-uniform':
                log10_A = parameter.Uniform(logmin, logmax)
            gamma = parameter.Uniform(0, 7)

            # PSD
            if psd == 'powerlaw':
                chm_prior = utils.powerlaw(log10_A=log10_A, gamma=gamma)
            elif psd == 'turnover':
                kappa = parameter.Uniform(0, 7)
                lf0 = parameter.Uniform(-9, -7)
                chm_prior = utils.turnover(log10_A=log10_A, gamma=gamma,
                                           lf0=lf0, kappa=kappa)

        if psd == 'spectrum':
            if prior == 'uniform':
                log10_rho = parameter.LinearExp(-10, -4, size=components)
            elif prior == 'log-uniform':
                log10_rho = parameter.Uniform(-10, -4, size=components)
            chm_prior = gpp.free_spectrum(log10_rho=log10_rho)

    elif gp_kernel == 'nondiag':
        if nondiag_kernel == 'periodic':
            # Periodic GP kernel for DM
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)
            log10_p = parameter.Uniform(-4, 1)
            log10_gam_p = parameter.Uniform(-3, 2)

            chm_basis = gpk.linear_interp_basis_chromatic(dt=dt*const.day)
            chm_prior = gpk.periodic_kernel(log10_sigma=log10_sigma,
                                            log10_ell=log10_ell,
                                            log10_gam_p=log10_gam_p,
                                            log10_p=log10_p)

        elif nondiag_kernel == 'periodic_rfband':
            # Periodic GP kernel for DM with RQ radio-frequency dependence
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)
            log10_ell2 = parameter.Uniform(2, 7)
            log10_alpha_wgt = parameter.Uniform(-4, 1)
            log10_p = parameter.Uniform(-4, 1)
            log10_gam_p = parameter.Uniform(-3, 2)

            chm_basis = gpk.get_tf_quantization_matrix(df=df, dt=dt*const.day,
                                                       dm=True, dm_idx=idx)
            chm_prior = gpk.tf_kernel(log10_sigma=log10_sigma,
                                      log10_ell=log10_ell,
                                      log10_gam_p=log10_gam_p,
                                      log10_p=log10_p,
                                      log10_alpha_wgt=log10_alpha_wgt,
                                      log10_ell2=log10_ell2)

        elif nondiag_kernel == 'sq_exp':
            # squared-exponential kernel for DM
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)

            chm_basis = gpk.linear_interp_basis_chromatic(dt=dt*const.day,
                                                          idx=idx)
            chm_prior = gpk.se_dm_kernel(log10_sigma=log10_sigma,
                                         log10_ell=log10_ell)
        elif nondiag_kernel == 'sq_exp_rfband':
            # Sq-Exp GP kernel for Chrom with RQ radio-frequency dependence
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)
            log10_ell2 = parameter.Uniform(2, 7)
            log10_alpha_wgt = parameter.Uniform(-4, 1)

            chm_basis = gpk.get_tf_quantization_matrix(df=df, dt=dt*const.day,
                                                       dm=True, dm_idx=idx)
            chm_prior = gpk.sf_kernel(log10_sigma=log10_sigma,
                                      log10_ell=log10_ell,
                                      log10_alpha_wgt=log10_alpha_wgt,
                                      log10_ell2=log10_ell2)

    cgp = gp_signals.BasisGP(chm_prior, chm_basis, name=name+'_gp',
                             coefficients=coefficients)

    if include_quadratic:
        # quadratic piece
        basis_quad = chrom.chromatic_quad_basis(idx=idx)
        prior_quad = chrom.chromatic_quad_prior()
        cquad = gp_signals.BasisGP(prior_quad, basis_quad, name=name+'_quad')
        cgp += cquad

    return cgp


# CUSTOM noise block.
# allows options to vary the chromatic index as a parameter
# and specify its prior range
def dm_exponential_dip(tmin, tmax, idx=2, idx_min=0, idx_max=6,
                       log10_tau_min=0, log10_tau_max=2.5,
                       log10_A_min=-10, log10_A_max=-2,
                       sign='negative', name='dmexp'):
    """
    Modified from enterprise_extensions to:
        allow options to vary the chromatic index as a parameter, and specify
            its prior range
    
    Returns chromatic exponential dip (i.e. TOA advance):
    :param tmin, tmax:
        search window for exponential dip time.
    :param idx:
        index of radio frequency dependence (i.e. DM is 2). If this is set
        to 'vary' then the index will vary from 1 - 6
    :param sign:
        set sign of dip: 'positive', 'negative', or 'vary'
    :param name: Name of signal
    :return dmexp:
        chromatic exponential dip waveform.
    """
    t0_dmexp = parameter.Uniform(tmin, tmax)
    log10_Amp_dmexp = parameter.Uniform(log10_A_min, log10_A_max)
    log10_tau_dmexp = parameter.Uniform(log10_tau_min, log10_tau_max)
    if sign == 'vary':
        sign_param = parameter.Uniform(-1.0, 1.0)
    elif sign == 'positive':
        sign_param = 1.0
    else:
        sign_param = -1.0
    if idx == 'vary':
        idx = parameter.Uniform(idx_min, idx_max)
    wf = chrom.chrom_exp_decay(log10_Amp=log10_Amp_dmexp,
                               t0=t0_dmexp, log10_tau=log10_tau_dmexp,
                               sign_param=sign_param, idx=idx)
    dmexp = deterministic_signals.Deterministic(wf, name=name)
    
    return dmexp

# CUSTOM noise block.
def dm_noise_block(gp_kernel='diag', psd='powerlaw', nondiag_kernel='periodic',
                   prior='log-uniform', dt=15, df=200,
                   logmin=-20, logmax=-11,
                   logmin_sigma=-10, logmax_sigma=-4,
                   logmin_fb=-9, logmax_fb=-7, min_kappa=0, max_kappa=7,
                   Tspan=None, components=30,
                   gamma_val=None, coefficients=False):
    """
    Modified from enterprise_extensions to:
        allows options to specify prior range on powerlaw params
        allows options to specify prior range on time-domain GP amplitude
    
    Returns DM noise model:
        1. DM noise modeled as a power-law with 30 sampling frequencies
    :param psd:
        PSD function [e.g. powerlaw (default), spectrum, tprocess,
                      broken_powerlaw]
    :param prior:
        Prior on log10_A. Default if "log-uniform". Use "uniform" for
        upper limits.
    :param dt:
        time-scale for linear interpolation basis (days)
    :param df:
        frequency-scale for linear interpolation basis (MHz)
    :param Tspan:
        Sets frequency sampling f_i = i / Tspan. Default will
        use overall time span for indivicual pulsar.
    :param components:
        Number of frequencies in sampling of DM-variations.
    :param gamma_val:
        If given, this is the fixed slope of the power-law for
        powerlaw, turnover, or tprocess DM-variations
    """
    # dm noise parameters that are common
    if gp_kernel == 'diag':
        if psd in ['powerlaw', 'broken_powerlaw', 'turnover',
                   'tprocess', 'tprocess_adapt']:
            # parameters shared by PSD functions
            if prior == 'uniform':
                log10_A_dm = parameter.LinearExp(logmin, logmax)
            elif prior == 'log-uniform' and gamma_val is not None:
                if np.abs(gamma_val - 4.33) < 0.1:
                    log10_A_dm = parameter.Uniform(logmin, logmax)
                else:
                    log10_A_dm = parameter.Uniform(logmin, logmax)
            else:
                log10_A_dm = parameter.Uniform(logmin, logmax)

            if gamma_val is not None:
                gamma_dm = parameter.Constant(gamma_val)
            else:
                gamma_dm = parameter.Uniform(0, 7)

            # different PSD function parameters
            if psd == 'powerlaw':
                dm_prior = utils.powerlaw(log10_A=log10_A_dm, gamma=gamma_dm)
            elif psd == 'broken_powerlaw':
                kappa = parameter.Uniform(min_kappa, max_kappa)
                log10_fb = parameter.Uniform(logmin_fb, logmax_fb)
                dm_prior = gpp.broken_powerlaw(log10_A=log10_A_dm,
                                               gamma=gamma_dm,
                                               delta=0, log10_fb=log10_fb,
                                               kappa=kappa)
            elif psd == 'turnover':
                kappa_dm = parameter.Uniform(min_kappa, max_kappa)
                lf0_dm = parameter.Uniform(logmin_fb, logmax_fb)
                dm_prior = utils.turnover(log10_A=log10_A_dm, gamma=gamma_dm,
                                          lf0=lf0_dm, kappa=kappa_dm)
            elif psd == 'tprocess':
                df = 2
                alphas_dm = gpp.InvGamma(df/2, df/2, size=components)
                dm_prior = gpp.t_process(log10_A=log10_A_dm, gamma=gamma_dm,
                                         alphas=alphas_dm)
            elif psd == 'tprocess_adapt':
                df = 2
                alpha_adapt_dm = gpp.InvGamma(df/2, df/2, size=1)
                nfreq_dm = parameter.Uniform(-0.5, 10-0.5)
                dm_prior = gpp.t_process_adapt(log10_A=log10_A_dm,
                                               gamma=gamma_dm,
                                               alphas_adapt=alpha_adapt_dm,
                                               nfreq=nfreq_dm)

        if psd == 'spectrum':
            if prior == 'uniform':
                log10_rho_dm = parameter.LinearExp(-10, -4, size=components)
            elif prior == 'log-uniform':
                log10_rho_dm = parameter.Uniform(-10, -4, size=components)

            dm_prior = gpp.free_spectrum(log10_rho=log10_rho_dm)

        dm_basis = utils.createfourierdesignmatrix_dm(nmodes=components,
                                                      Tspan=Tspan)

    elif gp_kernel == 'nondiag':
        if nondiag_kernel == 'periodic':
            # Periodic GP kernel for DM
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)
            log10_p = parameter.Uniform(-4, 1)
            log10_gam_p = parameter.Uniform(-3, 2)

            dm_basis = gpk.linear_interp_basis_dm(dt=dt*const.day)
            dm_prior = gpk.periodic_kernel(log10_sigma=log10_sigma,
                                           log10_ell=log10_ell,
                                           log10_gam_p=log10_gam_p,
                                           log10_p=log10_p)
        elif nondiag_kernel == 'periodic_rfband':
            # Periodic GP kernel for DM with RQ radio-frequency dependence
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)
            log10_ell2 = parameter.Uniform(2, 7)
            log10_alpha_wgt = parameter.Uniform(-4, 1)
            log10_p = parameter.Uniform(-4, 1)
            log10_gam_p = parameter.Uniform(-3, 2)

            dm_basis = gpk.get_tf_quantization_matrix(df=df, dt=dt*const.day,
                                                      dm=True)
            dm_prior = gpk.tf_kernel(log10_sigma=log10_sigma,
                                     log10_ell=log10_ell,
                                     log10_gam_p=log10_gam_p, log10_p=log10_p,
                                     log10_alpha_wgt=log10_alpha_wgt,
                                     log10_ell2=log10_ell2)
        elif nondiag_kernel == 'sq_exp':
            # squared-exponential GP kernel for DM
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)

            dm_basis = gpk.linear_interp_basis_dm(dt=dt*const.day)
            dm_prior = gpk.se_dm_kernel(log10_sigma=log10_sigma,
                                        log10_ell=log10_ell)
        elif nondiag_kernel == 'sq_exp_rfband':
            # Sq-Exp GP kernel for DM with RQ radio-frequency dependence
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)
            log10_ell = parameter.Uniform(1, 4)
            log10_ell2 = parameter.Uniform(2, 7)
            log10_alpha_wgt = parameter.Uniform(-4, 1)

            dm_basis = gpk.get_tf_quantization_matrix(df=df, dt=dt*const.day,
                                                      dm=True)
            dm_prior = gpk.sf_kernel(log10_sigma=log10_sigma,
                                     log10_ell=log10_ell,
                                     log10_alpha_wgt=log10_alpha_wgt,
                                     log10_ell2=log10_ell2)
        elif nondiag_kernel == 'dmx_like':
            # DMX-like signal
            log10_sigma = parameter.Uniform(logmin_sigma, logmax_sigma)

            dm_basis = gpk.linear_interp_basis_dm(dt=dt*const.day)
            dm_prior = gpk.dmx_ridge_prior(log10_sigma=log10_sigma)

    dmgp = gp_signals.BasisGP(dm_prior, dm_basis, name='dm_gp',
                              coefficients=coefficients)

    return dmgp

# Not sure if this actually changes anything important
def solar_wind_block(n_earth=None, ACE_prior=False, include_swgp=True,
                     swgp_prior=None, swgp_basis=None, Tspan=None,
                     selection=None):
    """
    Returns Solar Wind DM noise model. Best model from Hazboun, et al (in prep)
        Contains a single mean electron density with an auxiliary perturbation
        modeled using a gaussian process. The GP has common prior parameters
        between all pulsars, but the realizations are different for all pulsars
    Solar Wind DM noise modeled as a power-law with 30 sampling frequencies
    :param n_earth:
        Solar electron density at 1 AU.
    :param ACE_prior:
        Whether to use the ACE SWEPAM data as an astrophysical prior.
    :param swgp_prior:
        Prior function for solar wind Gaussian process. Default is a power law.
    :param swgp_basis:
        Basis to be used for solar wind Gaussian process.
        Options includes ['powerlaw'.'periodic','sq_exp']
    :param Tspan:
        Sets frequency sampling f_i = i / Tspan. Default will
        use overall time span for individual pulsar. Default is to use 15
        frequencies (1/Tspan,15/Tspan).
    """

    if n_earth is None and not ACE_prior:
        n_earth = parameter.Uniform(0, 30)
    elif n_earth is None and ACE_prior:
        n_earth = sw.ACE_SWEPAM_Parameter()
    else:
        pass
    deter_sw = sw.solar_wind(n_earth=n_earth)
    mean_sw = deterministic_signals.Deterministic(deter_sw, name='sw_r2')
    sw_model = mean_sw

    if include_swgp:
        if swgp_basis == 'powerlaw':
            # dm noise parameters that are common
            log10_A_sw = parameter.Uniform(-10, 1)
            gamma_sw = parameter.Uniform(-2, 1)
            sw_prior = utils.powerlaw(log10_A=log10_A_sw, gamma=gamma_sw)

            if Tspan is not None:
                freqs = np.linspace(1/Tspan, 30/Tspan, 30)
                freqs = freqs[1/freqs > 1.5*yr_in_sec]
                sw_basis = sw.createfourierdesignmatrix_solar_dm(modes=freqs)
            else:
                sw_basis = sw.createfourierdesignmatrix_solar_dm(nmodes=15,
                                                                 Tspan=Tspan)

        elif swgp_basis == 'periodic':
            # Periodic GP kernel for DM
            log10_sigma = parameter.Uniform(-10, -4)
            log10_ell = parameter.Uniform(1, 4)
            log10_p = parameter.Uniform(-4, 1)
            log10_gam_p = parameter.Uniform(-3, 2)

            sw_basis = gpk.linear_interp_basis_dm(dt=6*86400)
            sw_prior = gpk.periodic_kernel(log10_sigma=log10_sigma,
                                           log10_ell=log10_ell,
                                           log10_gam_p=log10_gam_p,
                                           log10_p=log10_p)
        elif swgp_basis == 'sq_exp':
            # squared-exponential GP kernel for DM
            log10_sigma = parameter.Uniform(-10, -4)
            log10_ell = parameter.Uniform(1, 4)

            sw_basis = gpk.linear_interp_basis_dm(dt=6*86400)
            sw_prior = gpk.se_dm_kernel(log10_sigma=log10_sigma,
                                        log10_ell=log10_ell)

        gp_sw = gp_signals.BasisGP(sw_prior, sw_basis, name='gp_sw')
        sw_model += gp_sw

    return sw_model


# CUSTOM NOISE BLOCK
def white_noise_block(vary=False, inc_ecorr=False, gp_ecorr=False,
                      efac1=False, select='backend', tnequad=False, name=None,
                      efac_min=0.01, efac_max=10, log_equad_min=-8.5,
                      log_equad_max=-5, efeq_groups=None, ecorr_groups=None):
    """
    Modified form enteprirse_extensions:
        allows you to change the prior ranges
            Note equad priors also used for ecorr
        recognizes select='DR3' to use input dictionaries for selection
    
    Returns the white noise block of the model:
        1. EFAC per backend/receiver system
        2. EQUAD per backend/receiver system
        3. ECORR per backend/receiver system
    :param vary:
        If set to true we vary these parameters
        with uniform priors. Otherwise they are set to constants
        with values to be set later.
    :param inc_ecorr:
        include ECORR, needed for NANOGrav channelized TOAs
    :param gp_ecorr:
        whether to use the Gaussian process model for ECORR
    :param efac1:
        use a strong prior on EFAC = Normal(mu=1, stdev=0.1)
    :param tnequad:
        Whether to use the TempoNest definition of EQUAD. Defaults to False to
        follow Tempo, Tempo2 and Pint definition.
    :param efeq_groups:
        Dictionary specifying which flag to use for each PTAs EFAC/EQUAD params
    :param ecorr_groups:
        Dictionary specifying which flag to use for each PTAs ECORR params
    """

    if select == 'backend':
        # define selection by observing backend
        backend = selections.Selection(selections.by_backend)
        # define selection by nanograv backends
        backend_sb = selections.Selection(selections.nanograv_backends)
        # backend_ch = selections.Selection(channelized_backends)
    elif select == 'DR3':
        CS = CustomSelections(efeq_groups, ecorr_groups)
        # define selection by observing backend
        backend = selections.Selection(CS.by_backend)
        # define selection by subbanded backends
        backend_sb = selections.Selection(CS.by_sb_backend)
        # currently running into a bug with the full DR3 ecorr funciton,
        # so just use NG for now
        # backend_sb = selections.Selection(nanograv_backends)
    else:
        # define no selection
        backend = selections.Selection(selections.no_selection)
        backend_sb = selections.Selection(selections.no_selection)

    # white noise parameters
    if vary:
        if efac1:
            efac = parameter.Normal(1.0, 0.1)
        else:
            efac = parameter.Uniform(efac_min, efac_max)
        equad = parameter.Uniform(log_equad_min, log_equad_max)
        if inc_ecorr:
            ecorr = parameter.Uniform(log_equad_min, log_equad_max)
    else:
        efac = parameter.Constant()
        equad = parameter.Constant()
        if inc_ecorr:
            ecorr = parameter.Constant()

    # white noise signals
    if tnequad:
        efeq = white_signals.MeasurementNoise(efac=efac,
                                              selection=backend, name=name)
        efeq += white_signals.TNEquadNoise(log10_tnequad=equad,
                                           selection=backend, name=name)
    else:
        efeq = white_signals.MeasurementNoise(efac=efac, log10_t2equad=equad,
                                              selection=backend, name=name)

    if inc_ecorr:
        if gp_ecorr:
            if name is None:
                ec = gp_signals.EcorrBasisModel(log10_ecorr=ecorr,
                                                selection=backend_sb)
            else:
                ec = gp_signals.EcorrBasisModel(log10_ecorr=ecorr,
                                                selection=backend_sb,
                                                name=name)

        else:
            ec = white_signals.EcorrKernelNoise(log10_ecorr=ecorr,
                                                selection=backend_sb,
                                                name=name)
    # combine signals
    if inc_ecorr:
        s = efeq + ec
    elif not inc_ecorr:
        s = efeq

    return s

